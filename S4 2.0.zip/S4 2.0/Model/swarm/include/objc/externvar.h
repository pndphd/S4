/* objc/externvar.h.  Generated from externvar.h.in by configure.  */
#ifndef _OBJC_EXTERNVAR_H
#define _OBJC_EXTERNVAR_H

#ifdef DLL_EXPORT
#define DLL
#endif

#if defined(DLL) && !defined(INHIBIT_OBJC_DLL)

#define EXPORT_EXTERN extern
#define IMPORT_EXTERN extern
#define EXPORT_EXTERNDEF 

#ifdef BUILDING_LIBOBJC

#ifdef EXPORT_EXTERN
#define externobjcvar EXPORT_EXTERN
#else
#define externobjcvar
#endif

#else

#ifdef IMPORT_EXTERN
#define externobjcvar IMPORT_EXTERN
#else
#define externobjcvar
#endif

#endif

#ifdef EXPORT_EXTERNDEF
#define externobjcvardef EXPORT_EXTERNDEF
#else
#define externobjcvardef
#endif

#else

#define externobjcvar extern
#define externobjcvardef

#endif


#endif

